#include "Game.h"
#include "opencv/highgui.h"
#include <fstream>
#include<iostream>
#include<stdio.h>

#include"time.h"

#include <windows.h>
#include <mmsystem.h>
#pragma comment (lib,"WINMM.LIB")
CGame::CGame(void)
{
	m_score = 0;
	m_count = 0;
}


CGame::~CGame(void)
{
}


void CGame::KeyRight(void)
{
	for(int i=0;i<3;i++)
	{
		m_heart.ToRight();
		Hit(&m_heart);
		cvWaitKey(1);
		Show();
	}
}


void CGame::KeyLeft(void)
{
	for(int i=0;i<3;i++)
	{
		m_heart.ToLeft();
		Hit(&m_heart);
		cvWaitKey(1);
		Show();
	}
}


void CGame::Hit(CHeart *heart)
{
	int i;
	for(i=0;i < m_dwarfs.size();i++)
	{
		if(	m_dwarfs[i].m_state == 1 && abs(m_dwarfs[i].m_position.x - heart->m_position.x) <= 20 && abs(m_dwarfs[i].m_position.y - heart->m_position.y)<=20)		
		{
			m_dwarfs[i].m_state = 2;
			m_heart.m_state = 2;
			mciSendString("play .//music//BE.wav", NULL, 0, NULL);
			m_score += 5;
			break;
		}
	}
	for(i=0 ; i < m_apples.size(); i++)
	{
		if(abs(m_apples[i].m_position.x - heart->m_position.x)<=20 && abs(m_apples[i].m_position.y - heart->m_position.y)<=20)
		{
			m_apples[i].m_state = 2;
			m_heart.m_state = 0;
			break;
		}
	}
}


void CGame::InitDwarfHeart(void)
{
	int i;

	for(i = 0; i < 7; i++)
	{
		m_dwarf[i].Init();
		m_dwarf[i].LoadImg(m_pDwarfImg[i]);
	}

	for(i=0;i<3;i++)
	{
		m_apple[i].Init();
		m_apple[i].LoadImg(m_pAppleImg[i]);
	}

	m_heart.Init();
	m_heart.LoadImg(m_pHeartImg);
}


void CGame::Init(void)
{
	InitImg();
	CreateScene();
	InitDwarfHeart();

}


void CGame::InitImg(void)
{
	char sceneryFilename[] = ".//picture//j000.jpg"; 
	for(int i = 0; i < 2; i++)
	{
		sprintf(sceneryFilename, ".//picture//j00%d.jpg", i);
		m_pSceneryImg[i] = cvLoadImage(sceneryFilename);
	}
	char dwarfFilename[] = ".//picture//1.png";
	for(int i = 0; i < 7; i++)
	{
		sprintf(dwarfFilename, ".//picture//%d.png", i+1);
		m_pDwarfImg[i] = cvLoadImage(dwarfFilename);
	}
	char AppleFilename[100] = ".//picture//8.png";
	for(int i = 0; i < 3; i++)
	{
		sprintf(AppleFilename, ".//picture//%d.png", i+8);
		m_pAppleImg[i] = cvLoadImage(AppleFilename);
	}
	m_pHeartImg = cvLoadImage(".//picture//heart2.png");

	m_size.width = 800;
	m_size.height = 600;
}


void CGame::Run(void)
{
	int i,x=0,time = 25;
	int preRunTime = GetTickCount();
	int currRunTime = GetTickCount();
	while(true)
	{	
		




		char key=cvWaitKey(time);
		

		

		if(m_count >= 58)
		{	

			if(key == 'a') 
			{
				KeyLeft();
				x=1;
			}
			else if(key == 'd') 
			{
				KeyRight();
				x=1;
			}
			if(m_heart.m_state == 1)  
			{
				m_heart.Down();
			}
			else if(m_heart.m_state == 2)   
			{	
				for(i=0;i<3;i++)
				{
					m_heart.Rebound();
					cvWaitKey(10);
					Show();
				}

				m_heart.m_state = 1;
			}	
		}

		
		


		
		if(key == ' ')
		{
			mciSendString("stop .//music//backgrand.mp3", NULL, 0, NULL);
			cvWaitKey(0);
		}

		if(key == 27)
		{
			mciSendString("stop .//music//backgrand.mp3", NULL, 0, NULL);
			break;	
		}




		currRunTime = GetTickCount();
		if(currRunTime - preRunTime > 40)
		{
			mciSendString("play .//music//backgrand.mp3", NULL, 0, NULL);
		m_count++;
		if(m_count % 220 == 0)
		{
			time -- ;
			if(time <= 3)
				time = 3;
		}
		if(m_count > 100000)
			m_count = 200;
		Hit(&m_heart);
		Show();

		if(m_count%25==0)
		{
			int k = rand()%7;
			m_dwarf[k].Init();
			m_dwarfs.push_back(m_dwarf[k]);
		}
		for(i=0;i<m_dwarfs.size();i++)
		{		
			if(m_dwarfs[i].m_state == 1)   
			{
				m_dwarfs[i].Up();
			}
			else if(m_dwarfs[i].m_state == 2)  
			{
				m_dwarfs[i].Down();
			}
		}

		if(m_count>=80)      
		{	
			for(i = 0; i < m_apples.size(); i++)
			{	
				if(m_apples[i].m_state == 1)
				{	
					m_apples[i].Up();
				}
			}
			if(m_count%130==0)
			{
				int k = rand()%3;	
				m_apple[k].Init();
				m_apples.push_back(m_apple[k]);
			}
		}

		if(m_heart.m_state == 0)	
		{
			mciSendString("play .//music//over.wav", NULL, 0, NULL);
			mciSendString("stop .//music//backgrand.mp3","",0,NULL);
			break;
		}
		preRunTime = currRunTime;
		}
	}
}


void CGame::Show(void)
{
	cvCopy(m_pImgBK, m_pImg);

	for(int i=0;i<m_dwarfs.size();i++)
	{
		m_dwarfs[i].Draw2BK(m_pImg);
	}	

	if(m_count>50)
	{
		m_heart.Draw2BK(m_pImg);	
	}

	if(m_count>=80)
	{
		for(int i=0;i<m_apples.size();i++)
		{
			m_apples[i].Draw2BK(m_pImg);
		}
	}

	char Grade[4], Level[3];
	CvFont font; 
	cvInitFont( &font, CV_FONT_HERSHEY_COMPLEX_SMALL - CV_FONT_HERSHEY_COMPLEX ,0.8, 0.8, 0.5, 2, 8);
	cvPutText(m_pImg, "level:" , cvPoint(700, 30), &font, CV_RGB(0,0,255));
	itoa((m_score)/50+1,Level,10); 
	cvPutText(m_pImg, Level , cvPoint(700, 55), &font, CV_RGB(255,0,0));
	cvPutText(m_pImg, "score:" , cvPoint(700,80), &font, CV_RGB(0,0,255));
	itoa(m_score,Grade,10); 
	cvPutText(m_pImg, Grade , cvPoint(700, 105), &font, CV_RGB(255,0,0));

	cvShowImage("Defending snow white", m_pImg);
}


void CGame::Release(void)
{
	cvReleaseImage(&m_pImgBK);
	cvReleaseImage(&m_pHeartImg);   

	for(int j = 0; j < 7; j++)
	{
		cvReleaseImage(&m_pDwarfImg[j]); 
	}
	for(int j = 0; j < 3; j++)
	{
		cvReleaseImage(&m_pAppleImg[j]);   
	}
	for(int j = 0; j < 2; j++)
	{
		cvReleaseImage(&m_pSceneryImg[j]);      
	}	
	cvReleaseImage(&m_pImg);
	cvDestroyWindow("Defending snow white");  
	cvReleaseImage(&m_pstartImage); 
	cvReleaseImage(&m_pmenuImage);  
	cvReleaseImage(&m_pintroductionImage);    
	cvReleaseImage(&m_pendImage);

	m_dwarfs.clear();
	m_apples.clear();
}


void CGame::CreateScene(void)
{
	ifstream in(".//map.txt");
	int num;
	in >> num;
	char str[] = ".//picture//back1.png";
	sprintf(str, ".//picture//back%d.png", num);
	m_pImgBK = cvLoadImage(str);


	m_pImg = cvCreateImage(cvSize(m_pImgBK->width,m_pImgBK->height),m_pImgBK->depth,m_pImgBK->nChannels);

	int photo, pt_x, pt_y;


	while(!in.eof())
	{
		in >> photo >> pt_x >> pt_y;
		Draw2BK(m_pImgBK,m_pSceneryImg[photo],pt_x,pt_y);
	}
	in.close();
}


void CGame::Draw2BK(IplImage* pImgBK,IplImage* scenery,int x,int y)
{
	int i,j,r,g,b;
	for(i = 0 ; i < scenery->height; i++)
	{
		for(j = 0;j < scenery->width; j++)
		{
			b = CV_IMAGE_ELEM(scenery,unsigned char,i,
				j * 3 + 0);
			g = CV_IMAGE_ELEM(scenery,unsigned char,i,
				j * 3 + 1);
			r = CV_IMAGE_ELEM(scenery,unsigned char,i,
				j * 3 + 2);


			if(!(b == 255 && g == 255 && r == 255))
			{
				CV_IMAGE_ELEM(pImgBK,unsigned char,i + y,
					(j + x) * 3 + 0) =	b;

				CV_IMAGE_ELEM(pImgBK,unsigned char,i + y,
					(j + x) * 3 + 1) = g; 

				CV_IMAGE_ELEM(pImgBK,unsigned char,i + y,
					(j + x) * 3 + 2) = r;
			}
		}
	}
}


void CGame::LoadBKImg(void)
{
	m_pstartImage = cvLoadImage(".//picture//start.jpg");
	m_pmenuImage = cvLoadImage(".//picture//menu.png");
	m_pintroductionImage = cvLoadImage(".//picture//introduction.png");
	m_pendImage = cvLoadImage(".//picture//end.png");


}

void CGame::Welcome(void)
{
	LoadBKImg();
	srand((unsigned) time(NULL));
	cvNamedWindow("Defending snow white", 1);
	cvShowImage("Defending snow white",m_pstartImage);
	mciSendString("play .//music//start.wav","",0,NULL);
	cvWaitKey(2000);
	cvReleaseImage(&m_pstartImage);
}


void CGame::Showend(void)
{
	char Grade[4];
	CvFont font; 
	cvInitFont( &font, CV_FONT_HERSHEY_COMPLEX_SMALL - CV_FONT_HERSHEY_COMPLEX ,2.5, 2.5, 0.6, 4, 8);
	itoa(m_score,Grade,10); 
	cvPutText(m_pendImage, Grade , cvPoint(115, 190), &font, CV_RGB(255,0,0));
}
