#include "opencv/highgui.h"
#include "time.h"
#include "Game.h"

#include <iostream>
using namespace std;

#include <windows.h>
#include <mmsystem.h>
#pragma comment (lib,"WINMM.LIB")   //�������ֵ�

char m_Sstate;
CGame game;

void on_mouse(int event, int x, int y, int flags, void *param)
{
	switch(event)
	{
	case CV_EVENT_LBUTTONDOWN:	
		if( x > 160 && x < 600 && y > 187 && y < 290)
		{
			m_Sstate = 1;
		}
		else if( x > 200 && x < 555 && y > 315 && y < 388)
		{
			m_Sstate = 2;
		}
		if( x > 700 && x < 760 && y > 515 && y < 555)
		{
			m_Sstate = 3;
		}
		if( x > 34 && x < 210 && y > 330 && y < 375 )
		{
			m_Sstate = 4;
		}
		else if( x > 205 && x < 380 && y > 418 && y < 460 )
		{
			m_Sstate = 5;
		}
		break;
	}
}


int main()
{
	game.Init();	
	game.Welcome();
	while(1)
	{
		cvShowImage("Defending snow white",game.m_pmenuImage);
		m_Sstate = 0;
		cvSetMouseCallback("Defending snow white",on_mouse, NULL);	
		char key = cvWaitKey(1);
		if(key == 's'||m_Sstate == 1)
		{
			mciSendString("stop .//music//start.wav","",0,NULL);
			mciSendString("play .//music//key.wav","",0,NULL);
			cvReleaseImage(&game.m_pmenuImage);
			break;
		}
		else if(key == 'i'||m_Sstate == 2)
		{
			mciSendString("play .//music//key.wav","",0,NULL);
			while(1)
			{
				cvShowImage("Defending snow white",game.m_pintroductionImage);
				cvWaitKey(1);
				cvSetMouseCallback("Defending snow white",on_mouse, NULL);
				if(m_Sstate == 3)
				{
					mciSendString("play .//music//key.wav","",0,NULL);
					cvReleaseImage(&game.m_pintroductionImage);
					break;
				}
			}
			m_Sstate = 0;
		}
	}

	while(1)
	{  
		CGame game;
		game.Init();
		game.Run();
		game.LoadBKImg();
		mciSendString("play .//music//end.mid", NULL, 0, NULL);
		game.Showend();
		while(1)
		{
			cvShowImage("Defending snow white",game.m_pendImage);
			cvSetMouseCallback("Defending snow white",on_mouse, NULL);
			char key = cvWaitKey(1);
			if( key == 's'||m_Sstate == 4)
			{
				mciSendString("play .//music//key.wav","",0,NULL);
				mciSendString("stop .//music//end.mid", NULL, 0, NULL);
				m_Sstate = 0;
				break;
			}	
			if(key == 27||key == 'q'||m_Sstate == 5)
			{
				mciSendString("play .//music//key.wav","",0,NULL);
				mciSendString("stop .//music//end.mid", NULL, 0, NULL);
				m_Sstate = 6;
				break;
			}
		}
		if(m_Sstate == 6)
		{
			break;
		}
		cvReleaseImage(&game.m_pendImage); 	
	}
	game.Release();
	return 0;
}