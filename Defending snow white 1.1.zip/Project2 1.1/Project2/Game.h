#pragma once
#include<vector>
using namespace std;
#include "DwarfApple.h"
#include "Heart.h"
class CGame
{
public:
	CGame(void);
	~CGame(void);
	void KeyRight(void);
	void KeyLeft(void);

	vector <CDwarfApple> m_dwarfs;
	CDwarfApple m_dwarf[7];
	vector <CDwarfApple> m_apples;
	CDwarfApple m_apple[3];
	IplImage* m_pDwarfImg[7];
	IplImage* m_pAppleImg[3];
	CvSize m_size;
	CHeart m_heart;
	int m_score;
	__int64 m_count;
	IplImage* m_pImgBK;
	IplImage* m_pImg;
	IplImage* m_pHeartImg;
	IplImage* m_pSceneryImg[2];
	void Hit(CHeart *heart);
	void InitDwarfHeart(void);
	void Init(void);
	void InitImg(void);
	void Run(void);
	void Show(void);
	void Release(void);
	void CreateScene(void);
	void Draw2BK(IplImage* pImgBK,IplImage* scenery,int x,int y);
	void LoadBKImg(void);
	IplImage* m_pstartImage;
	IplImage* m_pmenuImage;
	IplImage* m_pintroductionImage;
	IplImage* m_pendImage;
	void Welcome(void);
	void Showend(void);
};

