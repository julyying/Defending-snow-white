#include "Heart.h"
#include<stdio.h>
#include "opencv/highgui.h"

CHeart::CHeart(void)
{
	m_state = 1;//���״̬
}


CHeart::~CHeart(void)
{
}


void CHeart::Rebound(void)
{
	//����8��
	for(int i=0;i<8;i++)
	{
		m_position.y -= 3 * m_speed ;
		//�жϱ߽�
		if(m_position.y <= 1)
		{
			m_position.y = 0;
		}
		else if(m_position.y >= 550)
		{
			m_state = 0;
		}
		if(m_position.x>=761)
		{
			m_position.x -= m_speed;
		} 
		else if(m_position.x<=-12)
		{
			m_position.x += m_speed; 
		}
	}   
}

//������
void CHeart::Down(void)
{
	if(m_position.y<=560)
	{ 
		m_position.y += m_speed;
	}
	else
	{
		m_state = 0; //���ڵ��ϣ���ʧ
	}
}

//����
void CHeart::ToRight(void)
{
	if(m_position.x <= 761)
	{
		m_position.x += 3*m_speed;
	}
	else
	{
		m_position.x = 762;
	}
	if(m_position.y<=560)
	{ 
		m_position.y += 0.5*m_speed;
	}
	else
	{
		m_state = 0; 
	}
}

//����
void  CHeart::ToLeft(void)
{
	if(m_position.x>=-12)
	{
		m_position.x -= 3*m_speed;
	}
	else
	{
		m_position.x = -13;
	}
	if(m_position.y <= 560)
	{ 
		m_position.y += 0.5*m_speed;
	}
	else
	{
		m_state = 0; //���ڵ��ϣ���ʧ
	}
}

//��ʼ��
void CHeart::Init(void)
{
	m_position.x = ( rand() %200 ) + 300;
	m_position.y = 0;
	m_speed = 4;
	m_size.width = 17;
	m_size.height = 15;
}

//����ͼƬ
void CHeart::LoadImg(IplImage *pImg)
{
	m_pImg = pImg;
}

//����ͼƬ��������
void CHeart::Draw2BK(IplImage *pImgBK)
{
	if(m_state==0)
	{
		return;
	}

	int i,j,r,g,b;
	int x = m_position.x;
	int y = m_position.y;
	for(i = 0 ; i < m_pImg->height; ++i)
	{
		for(j = 0;j < m_pImg->width; ++j)
		{
			
            b = CV_IMAGE_ELEM(m_pImg,unsigned char,i,
				j * 3 + 0);
            g = CV_IMAGE_ELEM(m_pImg,unsigned char,i,
				j * 3 + 1);
			r = CV_IMAGE_ELEM(m_pImg,unsigned char,i,
				j * 3 + 2);
			
			int x1 = m_position.x + j;
			int y1 = m_position.y + i;
			if (y1 > 590)
			{
				break;
			}
			
            if(!(b >= 200 && g >= 200 && r >= 200))
			{
				CV_IMAGE_ELEM(pImgBK,unsigned char,i + y,(j + x) * 3 + 0) =	b;
		
				CV_IMAGE_ELEM(pImgBK,unsigned char,i + y,(j + x) * 3 + 1) = g; 
				
				CV_IMAGE_ELEM(pImgBK,unsigned char,i + y,(j + x) * 3 + 2) = r;
			}
		}
	}
}
