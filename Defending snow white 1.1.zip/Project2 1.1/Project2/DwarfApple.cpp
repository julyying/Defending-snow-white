#include "DwarfApple.h"
#include "opencv/highgui.h"

CDwarfApple::CDwarfApple(void)
{
	m_state=1; 
	countB = 0;
}


CDwarfApple::~CDwarfApple(void)
{
}


void CDwarfApple::Down(void)
{
	if(m_position.y >= 525)
	{
		m_state = 0;
		return;
	}
	else
	{
		m_state = 2;
		m_position.y += (4 * m_speed);
	}
}


void CDwarfApple::Up(void)
{
	if(m_position.y<=3)
	{
		m_state =0;
		Init();
		return;
	}
	else
	{
		m_state = 1;
		m_position.y -=m_speed;
	}
}


void CDwarfApple::LoadImg(IplImage *pImg)
{
	m_pImg = pImg;
}


void CDwarfApple::Draw2BK(IplImage *pImgBK)
{
	if(m_state==0)
	{
		return;
	}
	int w = m_pImg->width;
	int h = m_pImg->height;
	for(int y = 0; y < h; y++)
	{
		for(int x = 0; x < w; x++)
		{
			unsigned char b,g,r;
			b = CV_IMAGE_ELEM(m_pImg, unsigned char, y, x * 3);
			g = CV_IMAGE_ELEM(m_pImg, unsigned char, y, x * 3 + 1);
			r = CV_IMAGE_ELEM(m_pImg, unsigned char, y, x * 3 + 2);
			int x1 = m_position.x + x;
			int y1 = m_position.y + y;
			if (y1 > 590)
			{
				break;
			}
			if(!(b == 0 && g == 255 && r == 0))
			{
				CV_IMAGE_ELEM(pImgBK, unsigned char, y1, x1 * 3 + 0) = b;
				CV_IMAGE_ELEM(pImgBK, unsigned char, y1, x1 * 3 + 1) = g;
				CV_IMAGE_ELEM(pImgBK, unsigned char, y1, x1 * 3 + 2) = r;
			}
		}
	}
}


void CDwarfApple::Init(void)
{
	countB++;
	if(countB >= 100000)
		countB = 10;
	if(countB % 3 == 0)
	{
		m_position.x = ( rand() % 200 ) + 300;
	}
	else
	{
		m_position.x = ( rand() % 550 ) + 80;
	}
	m_position.y = 552;
	m_speed = 4;
	m_size.width = 50;
	m_size.height = 50;
}
